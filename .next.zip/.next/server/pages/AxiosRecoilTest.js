"use strict";
(() => {
var exports = {};
exports.id = 49;
exports.ids = [49];
exports.modules = {

/***/ 1001:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_AxiosRecoilTest),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(1844);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(9755);
;// CONCATENATED MODULE: ./src/app/recoil/atoms/atoms.ts

//recoil state 생성
const contentState = (0,external_recoil_.atom)({
    key: "content",
    default: {
        name: "test",
        status: false,
        message: ""
    }
});
const initialState = "";
const textState = (0,external_recoil_.atom)({
    key: "textState",
    default: initialState
});

;// CONCATENATED MODULE: ./src/app/recoil/selectors/selectors.ts


const charCountState = (0,external_recoil_.selector)({
    key: "charCountState",
    get: ({ get  })=>{
        const text = get(textState);
        return text.length;
    }
});
const myQuery = (0,external_recoil_.selector)({
    key: "myQuery",
    get: async ({ get  })=>{
        let _a;
        const _address = "https://kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=f5eef3421c602c6cb7ea224104795888&targetDt=20230527";
        await fetch(_address).then(function(response) {
            return response.json();
        }).then(function(myJson) {
            _a = JSON.parse(JSON.stringify(myJson)).boxOfficeResult.dailyBoxOfficeList;
            return _a;
        });
        const result = _a;
        return result;
    //const response1 = await fetch(_address);
    //const response2 = await response1.json();
    //return JSON.parse(JSON.stringify(response2)).boxOfficeResult.dailyBoxOfficeList;
    // const res = await axios.get(_address);
    // const res2 = await res.data;
    // return JSON.parse(JSON.stringify(res2)).boxOfficeResult.dailyBoxOfficeList;
    }
}); // Support for Data Fetching
 // 데이터를 가져오고 컴포넌트 내부에서 promise를 처리하는 강력하고 새로운 방법
 /**
 * 
// app/page.js
async function getData() {
  const res = await fetch("https://api.example.com/...");
  // The return value is *not* serialized
  // You can return Date, Map, Set, etc.
  return res.json();
}

// This is an async Server Component
export default async function Page() {
  const data = await getData();

  return <main>...</main>;
}


// next/image
Next.js 13은 강력한 새 이미지 구성 요소 를 도입하여 레이아웃 변경 없이 이미지를 쉽게 표시하고 성능 향상을 위해 필요에 따라 파일을 최적화할 수 있다고 한다.
더 적은 클라이언트 측 JavaScript 제공
더 쉬운 스타일 지정 및 구성
alt기본적으로 더 쉽게 액세스할 수 있는 필수 태그
웹 플랫폼과 일치
기본 지연 로딩에 수화가 필요하지 않기 때문에 더 빠름
import Image from "next/image";
import avatar from "./lee.png";
function Home() {
  // "alt" is now required for improved accessibility
  // optional: image files can be colocated inside the app/ directory
  return <Image alt="leeerob" src={avatar} placeholder="blur" />;
}
기존에는 width와 height를 지정해줘야 했지만 이제는 자동으로 제공해주는 것 같다.

조금 더 편리해지고 성능도 개선이 된 것 같다.
*/ 

;// CONCATENATED MODULE: ./src/components/Layout.tsx

const Layout = ({ children  })=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                children: "헤더 밑에 레이아웃"
            }),
            children
        ]
    });

;// CONCATENATED MODULE: ./pages/AxiosRecoilTest.tsx







// https://parkgang.github.io/blog/2021/05/06/using-recoil-in-nextjs/
// function AxiosRecoilTest({ Component, pageProps }: AppProps) {
const AxiosRecoilTest = ({ data  })=>{
    const myQuery_ = (0,external_recoil_.useRecoilValueLoadable)(myQuery);
    console.log("myQuery_;;;;;", myQuery_);
    const textState1 = (0,external_recoil_.useRecoilState)(textState);
    console.log("textState1s;;;;;", textState1);
    console.log("serverSideProps;;;data;;;", data);
    (0,external_react_.useEffect)(()=>{
    //recoil setting 
    }, []);
    const router = (0,router_.useRouter)();
    switch(myQuery_.state){
        case "hasValue":
            return /*#__PURE__*/ (0,jsx_runtime.jsxs)(Layout, {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("h1", {
                        children: "AxiosRecoilTest"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h1", {
                        children: "영화 리스트 목록(리코일 방식 데이터 뿌리기)"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("br", {}),
                    myQuery_.contents.map((val, index)=>{
                        // console.log('val;;;', val);
                        return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            children: [
                                val.rank,
                                ", ",
                                val.movieNm,
                                ", ",
                                val.openDt,
                                ", ",
                                val.showCnt
                            ]
                        }, val.rank);
                    })
                ]
            });
        case "loading":
            return /*#__PURE__*/ jsx_runtime.jsx("div", {
                children: "Loading..."
            });
        case "hasError":
            return /*#__PURE__*/ jsx_runtime.jsx("div", {
                children: "error..."
            });
    }
};
const getServerSideProps = async ()=>{
    // 서버 측에서 데이터를 가져와 props로 전달합니다.
    const res = await fetch("https://kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=f5eef3421c602c6cb7ea224104795888&targetDt=20230527");
    const data = await res.json();
    console.log("serverside;;;", data);
    return {
        props: {
            data
        }
    };
};
/* harmony default export */ const pages_AxiosRecoilTest = (AxiosRecoilTest); /*
  위의 예제에서 getServerSideProps 함수는 fetch를 사용하여 외부 API에서 데이터를 가져옵니다. 
  이 데이터는 props 객체의 속성으로 설정되고 MyPage 컴포넌트로 전달됩니다. 
  이후 MyPage 컴포넌트에서 data 속성을 사용하여 UI를 렌더링합니다.

  이 코드는 Next.js 프레임워크에서 사용되며, 서버 사이드 렌더링(SSR)을 지원하는 환경에서 실행됩니다. 
  클라이언트에서 해당 페이지로 요청이 들어올 때마다 서버에서 데이터를 가져와 페이지를 렌더링하므로 
  최초 로딩 시 서버에서 데이터를 가져와 초기 상태를 설정하는 데 사용됩니다.
*/  /**
 * 
const ItemList = ({ data }: IProps) => {
  return (
    <div>
      {data.map((data) => (
        <Link href={`/dynamic/${data.id}`} key={data.id}>
          <div key={data.id}>{data.name}</div>
        </Link>
      ))}
    </div>
  );
};

export default ItemList;

import { useState, useEffect } from "react";
import axios from "axios";
import Head from "next/head";
import ItemList, { IItem } from "../component/itemList";

const Index = () => {
  // 임시 API URL
  const API_URL =
    "http://makeup-api.herokuapp.com/api/v1/products.json?brand=maybelline";

  // 상태 생성
  const [list, setList] = useState<IItem[]>([]);

  // API 요청 후 상태에 저장
  const getData = () => {
    axios.get(API_URL).then((res) => {
      setList(res.data);
    });
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <div>
      <Head>
        <title>Next</title>
      </Head>
      <p>Hello Next.js</p>
      <ItemList data={list} />
    </div>
  );
};

export default Index;

 * 
 */ 


/***/ }),

/***/ 8038:
/***/ ((module) => {

module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [844], () => (__webpack_exec__(1001)));
module.exports = __webpack_exports__;

})();